Opject-oriented practice 2020   
-  
**Elena Evdokimova**  
  
Development of The problem statement.
Created Agent class with next filds:  
agentID  
List of advertising  
agentPayment  
List of advertising id  
  
comment1  
apdated Advertising class  
added advertisingId and responsibleAgentId fileds to OneToMany connection  
